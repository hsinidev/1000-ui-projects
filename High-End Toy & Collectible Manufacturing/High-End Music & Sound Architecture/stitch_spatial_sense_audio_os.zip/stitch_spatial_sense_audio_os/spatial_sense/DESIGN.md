---
name: Spatial-Sense
colors:
  surface: '#131314'
  surface-dim: '#131314'
  surface-bright: '#39393a'
  surface-container-lowest: '#0e0e0f'
  surface-container-low: '#1b1b1d'
  surface-container: '#1f1f21'
  surface-container-high: '#2a2a2b'
  surface-container-highest: '#353436'
  on-surface: '#e5e2e3'
  on-surface-variant: '#c6c6cd'
  inverse-surface: '#e5e2e3'
  inverse-on-surface: '#303031'
  outline: '#909097'
  outline-variant: '#45464c'
  surface-tint: '#c0c6db'
  primary: '#c0c6db'
  on-primary: '#293041'
  primary-container: '#0b1221'
  on-primary-container: '#777d90'
  inverse-primary: '#575e70'
  secondary: '#c5c7c8'
  on-secondary: '#2e3132'
  secondary-container: '#494c4d'
  on-secondary-container: '#babcbd'
  tertiary: '#bcc7dd'
  on-tertiary: '#263142'
  tertiary-container: '#071323'
  on-tertiary-container: '#737e93'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dce2f8'
  primary-fixed-dim: '#c0c6db'
  on-primary-fixed: '#151b2b'
  on-primary-fixed-variant: '#404758'
  secondary-fixed: '#e1e3e4'
  secondary-fixed-dim: '#c5c7c8'
  on-secondary-fixed: '#191c1d'
  on-secondary-fixed-variant: '#454748'
  tertiary-fixed: '#d8e3fa'
  tertiary-fixed-dim: '#bcc7dd'
  on-tertiary-fixed: '#111c2c'
  on-tertiary-fixed-variant: '#3c475a'
  background: '#131314'
  on-background: '#e5e2e3'
  surface-variant: '#353436'
typography:
  display-xl:
    fontFamily: Geist
    fontSize: 72px
    fontWeight: '300'
    lineHeight: 80px
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  container-margin: 32px
  gutter: 20px
---

## Brand & Style
The design system is centered on the concept of "Sonic Clarity." It is designed for high-end residential and professional audio environments where the interface must feel as premium as the hardware it controls. The brand personality is serene, sophisticated, and invisible—stepping back to let the album art and the music take center stage. 

The visual language heavily utilizes **Glassmorphism** to create a sense of physical depth within a digital space. This mimics high-end audio equipment materials like brushed aluminum and tempered glass. The emotional response is one of calm and precision, ensuring that multi-room management feels effortless rather than overwhelming.

## Colors
The palette is deeply rooted in the night. The base is **Midnight Blue (#0B1221)**, providing a high-contrast foundation that makes white typography pop without the harshness of pure black. 

**Silk White (#F8F9FA)** is used sparingly for primary content and interactive states to maintain a "glow" effect. 

**Frosted Glass** surfaces are achieved using a semi-transparent white tint with a heavy backdrop blur (40px+). To simulate "sound pressure," organic gradients are applied to backgrounds, using subtle shifts between midnight blues and deep charcoal to create a sense of movement and vibration.

## Typography
This design system utilizes **Geist** for its technical precision and monospaced-adjacent aesthetics, which resonate with professional audio engineering. 

The typographic hierarchy is dramatic. Large, light-weight display sizes are used for active track titles or volume percentages to evoke a sense of scale. Labels are often rendered in all-caps with increased tracking to ensure legibility on translucent backgrounds. All text should utilize "Silk White" with varying opacities (100% for headers, 70% for secondary metadata) to maintain visual depth.

## Layout & Spacing
The layout follows a **fluid grid** model optimized for edge-to-edge interaction. Because the OS is used on tablets and wall-mounted displays, touch targets are generously spaced.

A dynamic 12-column grid is used for desktop/tablet views, while mobile transitions to a stacked single-column view. Spacing is governed by a strict 8px rhythm. Content is grouped into "Zones" (Rooms), with significant negative space (48px+) between zones to prevent visual clutter and accidental touches in a multi-room environment.

## Elevation & Depth
Depth is the primary navigator in this design system. It is achieved through **Glassmorphism** rather than traditional shadows.

1.  **Base Layer:** The solid Midnight Blue background.
2.  **Surface Layer:** Frosted glass cards with a 60% background blur and a 1px "Silk White" inner border at 10% opacity. This creates a "etched glass" edge.
3.  **Active Layer:** Elements that are being interacted with (like an active scrubber or selected room) receive a soft, diffused outer glow (0px 12px 32px rgba(0,0,0,0.4)) and increased glass transparency.

Avoid heavy black shadows; instead, use backdrop filters and border treatments to define edges.

## Shapes
The shape language is consistently **Rounded**. This softens the technical nature of the OS, making it feel more approachable and organic. 

Standard cards and buttons utilize a 1rem (16px) radius. Larger container modules for specific rooms or zones use a 1.5rem (24px) radius. Icons are built on a 24px grid with rounded terminals to match the container language.

## Components
- **Translucent Cards:** The primary container. Must feature a `backdrop-filter: blur(40px)` and a subtle 1px border. Background color should be `rgba(255, 255, 255, 0.05)`.
- **High-Precision Scrubbers:** Track progress and volume sliders consist of a thin 4px "Silk White" track (20% opacity) and a solid "Silk White" thumb. The active portion of the track should feature a subtle "sound-pressure" gradient.
- **Minimalist Iconography:** Line-based icons with a 1.5px stroke width. No filled states; use "Silk White" at 100% opacity for active and 40% for inactive.
- **Control Chips:** Small, pill-shaped buttons for toggling "Mute," "Shuffle," or "Repeat." These should be fully transparent with a 1px border until active, at which point they become frosted glass.
- **Zone Multipliers:** A unique component for grouping rooms. It appears as a floating glass ring that expands to encompass multiple room cards, visually "linking" them with a soft blue glow.
- **Input Fields:** Search and naming fields are borderless, appearing only as a slight lightening of the background glass (10% opacity) with a blinking Silk White cursor.