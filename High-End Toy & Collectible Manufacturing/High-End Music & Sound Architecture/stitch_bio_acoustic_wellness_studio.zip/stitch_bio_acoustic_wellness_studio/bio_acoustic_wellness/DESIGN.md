---
name: Bio-Acoustic Wellness
colors:
  surface: '#fbf9f9'
  surface-dim: '#dbdad9'
  surface-bright: '#fbf9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#e9e8e7'
  surface-container-highest: '#e4e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#434843'
  inverse-surface: '#303031'
  inverse-on-surface: '#f2f0f0'
  outline: '#737872'
  outline-variant: '#c3c8c1'
  surface-tint: '#506354'
  primary: '#334537'
  on-primary: '#ffffff'
  primary-container: '#4a5d4e'
  on-primary-container: '#c0d5c2'
  inverse-primary: '#b7ccb9'
  secondary: '#5c5d6e'
  on-secondary: '#ffffff'
  secondary-container: '#e1e1f5'
  on-secondary-container: '#626374'
  tertiary: '#404242'
  on-tertiary: '#ffffff'
  tertiary-container: '#575959'
  on-tertiary-container: '#cfd0d0'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d3e8d5'
  primary-fixed-dim: '#b7ccb9'
  on-primary-fixed: '#0e1f13'
  on-primary-fixed-variant: '#394b3d'
  secondary-fixed: '#e1e1f5'
  secondary-fixed-dim: '#c5c5d8'
  on-secondary-fixed: '#191b29'
  on-secondary-fixed-variant: '#444655'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#fbf9f9'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e2'
typography:
  headline-xl:
    fontFamily: Lexend
    fontSize: 48px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Lexend
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Lexend
    fontSize: 24px
    fontWeight: '400'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  xs: 0.25rem
  sm: 0.5rem
  md: 1rem
  lg: 2rem
  xl: 4rem
  gutter: 1.5rem
  margin: 2rem
---

## Brand & Style

This design system is rooted in **Biophilic Design**, bridging the gap between clinical efficacy and organic serenity. The brand personality is compassionate, sophisticated, and revitalizing—aimed at high-end wellness users seeking therapeutic relief through sound.

The visual style utilizes a refined **Glassmorphism** mixed with **Tactile** biological textures. UI elements should feel like they are floating in a gentle fluid, rather than fixed to a rigid grid. The "breathing" animation is a core tenet: interactive elements should subtly expand and contract in a slow, rhythmic tempo (approximately 6 breaths per minute) to encourage user heart-rate variability (HRV) synchronization. High-fidelity textures—resembling microscopic cellular structures or flowing water—should be used as subtle background overlays to provide a sense of biological depth.

## Colors

The palette is designed to lower cortisol levels and induce a state of "soft fascination." 

*   **Moss Green (#4A5D4E):** Used for primary actions, heavy typography, and grounding elements. It represents the "Bio" in Bio-Acoustics.
*   **Lavender (#E6E6FA):** Used for secondary surfaces, accents, and progress indicators. It provides a calming, ethereal contrast to the earthy green.
*   **Soft White (#FDFDFD):** The primary canvas color. It is intentionally off-white to reduce eye strain and provide a "paper-like" organic feel.
*   **Functional Gradients:** Backgrounds should utilize extremely soft linear gradients transitioning from Soft White to a very faint Lavender to create a sense of atmospheric depth.

## Typography

The typography strategy balances the precision of science with the warmth of wellness. 

**Lexend** is the choice for headings due to its unique origins in reading proficiency and its open, friendly character. It should be typeset with slightly tighter letter spacing for large display sizes to maintain a sophisticated editorial look.

**Inter** provides a utilitarian and highly legible foundation for body text and metadata. To maintain the "serene" aesthetic, line heights are intentionally generous (1.6x), ensuring that content never feels cramped or overwhelming. Use Moss Green for primary text and a 60% opacity variant for secondary descriptions.

## Layout & Spacing

The layout follows a **Fluid Grid** model with an emphasis on "negative space as a restorative element." 

A 12-column system is used for desktop, 8 for tablet, and 4 for mobile. However, content should rarely span the full width; instead, use wide margins to "cradle" the content in the center of the screen. Spacing follows a 4px baseline, but the primary rhythm is built on larger 16px (1rem) increments. Groupings of biological information should use "cluster" logic—organic positioning rather than strict vertical lists—wherever the technical constraints allow.

## Elevation & Depth

Depth in this design system is created through **Ambient Tonal Layers** and **Backdrop Blurs**. 

Avoid harsh black shadows. Instead, use "Biological Shadows"—extremely soft, long-distance blurs (30px+) with a very low opacity (5-8%) tinted with Moss Green. This makes elements feel like they are floating on a mossy forest floor or suspended in clear water. 

Glassmorphic surfaces should use a `backdrop-filter: blur(12px)` and a thin, 1px semi-transparent border (Soft White at 20% opacity) to define the edge of the "cell." This creates a sense of high-end clinical sophistication without feeling cold.

## Shapes

The shape language is strictly **Organic and Cyclical**. 

Standard containers use a roundedness of `1rem` (rounded-lg) to ensure no "sharp" edges interrupt the user's calm. For purely decorative elements or background containers, use "Blob" shapes with irregular radii (e.g., `60% 40% 30% 70% / 60% 30% 70% 40%`) to mimic cellular structures. These shapes should subtly rotate or warp over time using the aforementioned "breathing" animation logic.

## Components

### Buttons
Primary buttons are pill-shaped with a Moss Green background and Soft White text. The hover state should not change color but rather trigger a soft "glow" (a subtle outer shadow in Moss Green) and a slight scale increase (1.02x) as if the button is inhaling.

### Cards
Cards act as the primary containers for soundscapes. They use the Glassmorphic style: a Soft White base at 70% opacity, a backdrop blur, and a high-fidelity biological texture (like leaf veins or sand ripples) masked within the card.

### Input Fields
Inputs are minimalist, utilizing a simple Soft White background with a Moss Green 1px bottom border. On focus, the border should expand into a soft Lavender "breathing" pulse.

### Audio Visualizers
Instead of traditional "bars," audio should be visualized as expanding concentric circles or flowing "sound waves" that mimic the movement of water. Use Lavender for the wave strokes with a thickness of 2px.

### Progress Bars
Progress indicators for sound sessions should be thin, horizontal lines using a Lavender background and a Moss Green fill, with the "thumb" or current position marker being a soft, glowing Moss Green circle.