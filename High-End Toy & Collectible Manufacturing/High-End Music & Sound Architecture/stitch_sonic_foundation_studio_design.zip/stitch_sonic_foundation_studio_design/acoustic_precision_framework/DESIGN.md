---
name: Acoustic Precision Framework
colors:
  surface: '#121414'
  surface-dim: '#121414'
  surface-bright: '#38393a'
  surface-container-lowest: '#0d0f0f'
  surface-container-low: '#1a1c1c'
  surface-container: '#1e2020'
  surface-container-high: '#282a2b'
  surface-container-highest: '#333535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#c4c7c7'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#2f3131'
  outline: '#8e9192'
  outline-variant: '#444748'
  surface-tint: '#c8c6c5'
  primary: '#c8c6c5'
  on-primary: '#313030'
  primary-container: '#121212'
  on-primary-container: '#7e7d7d'
  inverse-primary: '#5f5e5e'
  secondary: '#ebbe95'
  on-secondary: '#452a0c'
  secondary-container: '#624323'
  on-secondary-container: '#dcb088'
  tertiary: '#b8c8da'
  on-tertiary: '#223240'
  tertiary-container: '#031320'
  on-tertiary-container: '#6f7f8f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#ffdcbe'
  secondary-fixed-dim: '#ebbe95'
  on-secondary-fixed: '#2c1600'
  on-secondary-fixed-variant: '#5f4021'
  tertiary-fixed: '#d4e4f6'
  tertiary-fixed-dim: '#b8c8da'
  on-tertiary-fixed: '#0d1d2a'
  on-tertiary-fixed-variant: '#394857'
  background: '#121414'
  on-background: '#e2e2e2'
  surface-variant: '#333535'
typography:
  display-xl:
    fontFamily: Geist
    fontSize: 72px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Geist
    fontSize: 40px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-tech:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.15em
spacing:
  base: 8px
  grid-columns: '12'
  gutter: 24px
  margin: 48px
  technical-unit: 4px
---

## Brand & Style

This design system is anchored in the concept of "Architectural Minimalism." It bridges the gap between raw technical data and high-end physical craftsmanship. The aesthetic mimics a digital drafting table, evoking the authority of an expert acoustic engineer.

The visual language utilizes "X-Ray" aesthetics—revealing the internal logic of a space through thin architectural linework and blueprint-inspired schematics. Imagery should lean into the contrast between the dark, silent atmosphere of a professional studio and the warm, tactile nature of acoustic treatments. The emotional response is one of absolute precision, silence, and structural integrity.

## Colors

The palette is strictly curated to reflect studio materials. **Charcoal (#121212)** serves as the "infinite quiet" background, representing the sound-treated environment. **Warm Oak (#B58D67)** is used sparingly as a high-end accent, signifying organic acoustic panels and human craftsmanship. **Slate (#708090)** is the technical bridge, used for secondary information, grid lines, and architectural annotations.

High-contrast white or off-white text ensures legibility against the charcoal base, while the slate provides a lower-hierarchy layer for measurements and metadata.

## Typography

The typographic system is built on a high-contrast hierarchy. **Geist** provides the structural, geometric foundation for headlines, feeling both modern and engineered. **Inter** is utilized for body copy to maintain professional clarity and neutrality. 

For technical data, frequency measurements, and architectural annotations, **JetBrains Mono** is used to inject a "monospaced/technical" character. This distinction ensures that data-heavy views feel like an authentic engineering report.

## Layout & Spacing

This design system employs a rigid 12-column fixed grid that echoes architectural blueprints. Content is strictly aligned to a 4px baseline grid to ensure mathematical precision. 

Layouts should favor asymmetric balance, with generous white space (or "dark space") to let technical illustrations breathe. Spacing is used to group data logically: tight 4px or 8px increments for related technical specs, and larger 48px+ blocks for section breaks. Visible grid lines in a low-opacity Slate color are encouraged to reinforce the technical "drafting table" aesthetic.

## Elevation & Depth

Depth is conveyed through **Low-Contrast Outlines** and **Tonal Layering** rather than traditional shadows. Surfaces do not "float"; they are "etched" or "mounted."

1.  **Base Layer:** Charcoal (#121212) - The primary canvas.
2.  **Etched Layer:** A 1px solid border of Slate (#708090) at 30% opacity defines containers.
3.  **Active Layer:** Elements that require focus use a Warm Oak (#B58D67) border or a subtle 5% lighter charcoal fill.
4.  **Glassmorphism:** Used exclusively for overlays (e.g., frequency analyzers or CAD-style modals), using a dark background blur to simulate a glass-topped control console.

## Shapes

To maintain the architectural and "blueprint" aesthetic, the design system utilizes a **Sharp (0px)** corner radius for all primary UI elements, including buttons, cards, and input fields. 

Small, internal technical elements—such as status indicators or frequency nodes—may use a circular "Pill" shape to distinguish them as interactive data points, but the overarching container language remains strictly rectangular and structural.

## Components

### Buttons
Primary buttons use a solid Warm Oak background with black text for maximum prominence. Secondary buttons are "Ghost" style: sharp 1px Slate borders with JetBrains Mono text. Hover states should trigger a 1px solid white border, mimicking a selection in a CAD program.

### Input Fields
Inputs are defined by a bottom-border only (Slate #708090), resembling a signature line on a blueprint. Labels use `label-caps` and are positioned strictly above the field.

### Cards & Modules
Containers must use the "X-Ray" style: no background fill, 1px Slate borders, and technical labels in the top-left corner using `label-tech`. This makes the interface feel like a series of technical drawings.

### Acoustic Visualizers
Custom components include frequency response graphs and 3D room heatmaps. These should use thin Slate linework and Warm Oak highlights for the "sweet spot" or peak values.

### Chips & Tags
Technical metadata tags use `label-tech` with a Slate border and no fill. They are used for categorizing acoustic materials (e.g., "Diffusion," "Absorption," "Bass Trap").