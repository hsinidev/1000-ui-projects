---
name: Luthier-Luxe Design System
colors:
  surface: '#fff8f7'
  surface-dim: '#fdcfcb'
  surface-bright: '#fff8f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff0ef'
  surface-container: '#ffe9e6'
  surface-container-high: '#ffe2de'
  surface-container-highest: '#ffdad6'
  on-surface: '#2d1512'
  on-surface-variant: '#524342'
  inverse-surface: '#452926'
  inverse-on-surface: '#ffedeb'
  outline: '#847371'
  outline-variant: '#d7c2c0'
  surface-tint: '#874f4a'
  primary: '#300a08'
  on-primary: '#ffffff'
  primary-container: '#4a1e1b'
  on-primary-container: '#c3827c'
  inverse-primary: '#fcb5ae'
  secondary: '#735c00'
  on-secondary: '#ffffff'
  secondary-container: '#fed65b'
  on-secondary-container: '#745c00'
  tertiary: '#1b1708'
  on-tertiary: '#ffffff'
  tertiary-container: '#302c1a'
  on-tertiary-container: '#9a937c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#fcb5ae'
  on-primary-fixed: '#360e0c'
  on-primary-fixed-variant: '#6b3834'
  secondary-fixed: '#ffe088'
  secondary-fixed-dim: '#e9c349'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#ebe2c8'
  tertiary-fixed-dim: '#cec6ad'
  on-tertiary-fixed: '#1f1c0b'
  on-tertiary-fixed-variant: '#4c4733'
  background: '#fff8f7'
  on-background: '#2d1512'
  surface-variant: '#ffdad6'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  title-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-md:
    fontFamily: Source Sans Three
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Source Sans Three
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: 0.15em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1200px
  gutter: 32px
  margin: 64px
  section-padding: 128px
---

## Brand & Style

The design system is rooted in the "Bespoke Artisanal" movement, blending **Tactile Skeuomorphism** with **Minimalist** layout principles. It targets discerning musicians and collectors who value the intersection of historical craftsmanship and technical precision. The UI must evoke the sensory experience of a high-end luthier's workshop—the scent of aged wood, the glint of polished varnish, and the silence of a focused studio. 

Key visual pillars include:
- **Historical Precision:** Utilizing classical proportions and traditional serif typography.
- **Human Connection:** Incorporating subtle organic textures (wood grain, parchment) to avoid a cold, digital feel.
- **Exceptionalism:** Using high-contrast metallic accents to highlight quality and "gold standard" engineering.

## Colors

The palette is inspired by the materials of instrument making. 
- **Deep Mahogany (#4A1E1B):** Used for primary grounding elements, headers, and rich backgrounds to signify depth and strength.
- **Metallic Gold (#D4AF37):** Reserved for interactive highlights, borders of distinction, and fine iconography.
- **Aged Parchment (#F4EBD0):** The primary canvas color, providing a softer, more historical alternative to pure white.
- **Neutral Dark (#2A1210):** Used for high-contrast body text on parchment to ensure legibility while maintaining the warm tonal range.

## Typography

The typographic hierarchy relies on the contrast between the romantic, high-contrast strokes of **Playfair Display** and the functional, neutral clarity of **Source Sans Three**. 

- **Headlines:** Use Playfair Display. For a more bespoke feel, use the Italic variant for sub-headlines or featured quotes to mimic traditional musical notation styling.
- **Body Text:** Source Sans Three is utilized for its high x-height and readability against textured backgrounds.
- **Labels:** Small caps with increased letter spacing are used for navigation and technical specifications, echoing the precision of a blueprint or a certificate of authenticity.

## Layout & Spacing

This design system employs a **Fixed Grid** philosophy to maintain an editorial, "coffee-table book" aesthetic. 
- **Generous Whitespace:** Margins and section padding are intentionally oversized to convey luxury and allow the instrument photography room to breathe.
- **Rhythm:** A strict 8px baseline grid ensures that despite the organic textures, the layout feels mathematically precise.
- **Alignment:** Elements should primarily be center-aligned for hero sections and brand-heavy pages, shifting to an asymmetric grid for technical galleries.

## Elevation & Depth

Depth is achieved through **Tonal Layering** and **Subtle Skeuomorphism** rather than heavy shadows.
- **Surface Tiering:** The Aged Parchment base layer sits at the bottom. Mahogany "inlays" or cards sit atop this.
- **Soft Shadows:** Use extremely diffused, mahogany-tinted shadows (e.g., `rgba(42, 18, 16, 0.08)`) to give components a slight lift from the surface, as if they are physical objects resting on a desk.
- **Glints:** Apply 1px gold inner-borders to primary components to simulate light catching the edge of a polished tool or instrument rim.

## Shapes

The shape language is conservative and structural.
- **Corner Radius:** A subtle 4px (Soft) radius is applied to most containers to take the "edge" off the digital screen, mimicking hand-sanded wood.
- **Fine Lines:** Use 0.5px to 1px "hairline" strokes in Metallic Gold for dividers and borders. 
- **Organic Inlays:** Backgrounds for major sections should incorporate a very low-opacity wood-grain SVG pattern to reinforce the tactile nature of the brand.

## Components

- **Buttons:** Primary buttons are solid Deep Mahogany with Gold text. Secondary buttons are Gold-bordered with "ghost" backgrounds. Hover states should include a subtle "sheen" transition.
- **Sophisticated Cards:** Cards feature a 1px Gold border, a very faint parchment texture, and "Inset" photography. Images within cards should have a slight vignette.
- **Input Fields:** Fields use an "underline-only" style in Deep Mahogany to mimic traditional ledger entries, with Gold labels that float upward on focus.
- **Instrument Photography:** All imagery must use warm, directional lighting. Close-up "macro" shots of wood grain, strings, and f-holes are preferred over flat product shots.
- **Checkboxes & Radios:** Custom-styled to look like brass hardware or tuning pegs.
- **Signature Component (The Certificate):** A specialized layout component for instrument specs that uses a decorative gold filigree border and the `title-sm` italic serif font.