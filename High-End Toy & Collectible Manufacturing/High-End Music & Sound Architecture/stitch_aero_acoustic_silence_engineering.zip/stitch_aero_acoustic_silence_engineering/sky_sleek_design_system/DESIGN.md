---
name: Sky-Sleek Design System
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#516072'
  on-secondary: '#ffffff'
  secondary-container: '#d2e1f7'
  on-secondary-container: '#556477'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#161c22'
  on-tertiary-container: '#7e848c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#d4e4fa'
  secondary-fixed-dim: '#b9c8de'
  on-secondary-fixed: '#0d1c2d'
  on-secondary-fixed-variant: '#39485a'
  tertiary-fixed: '#dde3eb'
  tertiary-fixed-dim: '#c1c7cf'
  on-tertiary-fixed: '#161c22'
  on-tertiary-fixed-variant: '#41474e'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display:
    fontFamily: Metropolis
    fontSize: 72px
    fontWeight: '300'
    lineHeight: 80px
    letterSpacing: -0.02em
  h1:
    fontFamily: Metropolis
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 56px
    letterSpacing: -0.01em
  h2:
    fontFamily: Metropolis
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
    letterSpacing: 0.01em
  h3:
    fontFamily: Metropolis
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: 0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0.01em
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.01em
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  margin-page: 120px
  gutter: 32px
  section-gap: 160px
  container-max: 1440px
---

## Brand & Style

The design system is anchored in the concept of "Visual Silence." It mirrors the core product—noise-canceling architecture—by stripping away digital noise to focus on precision and atmospheric calm. The aesthetic is a fusion of **Minimalism** and **Modern Corporate**, utilizing expansive white space to represent the openness of the sky and the quiet of a sound-insulated cabin.

The target audience consists of high-net-worth individuals and aerospace engineers. Consequently, the UI must feel like a precision instrument: expensive, understated, and mathematically perfect. Every element exists with purpose, favoring thin strokes and structural alignment over decorative flourishes.

## Colors

This design system utilizes a high-contrast, professional palette that evokes the atmosphere of high-altitude flight and metallurgical precision.

*   **Deep Navy Blue (#0F172A):** Used for primary typography and structural foundations. It represents the depth of the stratosphere and provides a grounded, authoritative presence.
*   **Metallic Silver (#94A3B8):** Used for technical accents, hairline borders, and vector iconography. It suggests engineering materials and brushed aluminum.
*   **Cloud White (#F8FAFC):** The primary canvas color. It is a slightly cooled white that prevents eye strain while maintaining a pristine, sterile environment.
*   **Accent Slate (#E2E8F0):** Used for secondary UI elements and subtle hover states to maintain a low-chroma, "quiet" visual hierarchy.

## Typography

Typography in this design system is architectural. We pair **Metropolis** for headlines to provide a geometric, structured feel with **Inter** for body text to ensure functional, utilitarian legibility.

Large headings use a lighter weight (300) to feel airy and premium. Labels and navigational elements use uppercase Inter with increased letter spacing to emulate the technical markings found in aviation cockpits. Line heights are intentionally generous to reinforce the "quiet" nature of the layout.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy with extreme margins. Content is centered within a 1440px container, but significant padding (120px+) is maintained on the flanks to isolate the content and create a sense of exclusivity.

A strict 8px rhythmic grid governs all internal component spacing. Vertical rhythm is expanded; section gaps of 160px are standard to allow the design to "breathe." Grid gutters are kept wide (32px) to prevent information density from feeling claustrophobic.

## Elevation & Depth

This design system eschews traditional shadows in favor of **Low-Contrast Outlines** and **Tonal Layering**. 

Depth is achieved through 0.5pt or 1pt hairlines in Metallic Silver. When an element requires focus, it is elevated using a subtle background shift from Cloud White to a faint Slate tint. If a shadow is absolutely necessary for utility (e.g., a floating navigation bar), it must be a "long-shadow" style—highly diffused, nearly invisible (opacity < 5%), and tinted with the primary Navy Blue to maintain a premium, integrated feel.

## Shapes

The shape language is "Engineering Soft." We use a **Soft (0.25rem)** roundedness level. This provides just enough curvature to feel modern and approachable without losing the precision of a sharp, technical drawing. 

Containers and cards should feel like machined components. Large-scale structural elements (like hero images or main content blocks) should retain sharp corners or the absolute minimum radius to emphasize the architectural focus of the firm.

## Components

*   **Buttons:** Primary buttons use a solid Deep Navy Blue with white typography. Secondary buttons are "Ghost" style, using a 1px Metallic Silver border and no fill. All buttons feature a 0.1em letter spacing for their labels.
*   **Icons:** Use thin-line vector icons (1px stroke weight). Icons must never be filled; they should appear as wireframes to reinforce the engineering aesthetic.
*   **Inputs:** Input fields are defined by a single 1px bottom border rather than a full box, minimizing visual weight. Labels sit above in the `label-caps` style.
*   **Cards:** Cards are indicated by a 1px `tertiary_color` border. No shadows. The background remains `neutral_color`.
*   **Progress Indicators:** Use ultra-thin bars (2px height) to show loading or process states, utilizing the Metallic Silver for the track and Deep Navy for the progress.
*   **Navigation:** A minimalist top-bar with wide-spaced text links. Active states are indicated by a simple 1px underline or a weight shift rather than a color change.