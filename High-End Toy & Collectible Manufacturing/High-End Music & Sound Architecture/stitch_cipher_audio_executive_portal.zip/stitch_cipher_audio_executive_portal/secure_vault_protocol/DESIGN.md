---
name: Secure Vault Protocol
colors:
  surface: '#141218'
  surface-dim: '#141218'
  surface-bright: '#3b383e'
  surface-container-lowest: '#0f0d13'
  surface-container-low: '#1d1b20'
  surface-container: '#211f24'
  surface-container-high: '#2b292f'
  surface-container-highest: '#36343a'
  on-surface: '#e6e0e9'
  on-surface-variant: '#cbc4d2'
  inverse-surface: '#e6e0e9'
  inverse-on-surface: '#322f35'
  outline: '#948e9c'
  outline-variant: '#494551'
  surface-tint: '#cfbcff'
  primary: '#cfbcff'
  on-primary: '#381e72'
  primary-container: '#6750a4'
  on-primary-container: '#e0d2ff'
  inverse-primary: '#6750a4'
  secondary: '#cdc0e9'
  on-secondary: '#342b4b'
  secondary-container: '#4d4465'
  on-secondary-container: '#bfb2da'
  tertiary: '#e7c365'
  on-tertiary: '#3e2e00'
  tertiary-container: '#c9a74d'
  on-tertiary-container: '#503d00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#cfbcff'
  on-primary-fixed: '#22005d'
  on-primary-fixed-variant: '#4f378a'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#cdc0e9'
  on-secondary-fixed: '#1f1635'
  on-secondary-fixed-variant: '#4b4263'
  tertiary-fixed: '#ffdf93'
  tertiary-fixed-dim: '#e7c365'
  on-tertiary-fixed: '#241a00'
  on-tertiary-fixed-variant: '#594400'
  background: '#141218'
  on-background: '#e6e0e9'
  surface-variant: '#36343a'
typography:
  h1-secure:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    letterSpacing: -0.04em
  h2-technical:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '500'
    letterSpacing: -0.02em
  body-clean:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    letterSpacing: 0.05em
  label-caps:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '700'
    letterSpacing: 0.1em
---

## Brand & Style
The design system is engineered to evoke absolute trust through a visual language of impenetrable security. The aesthetic leans heavily into a "Technical Noir" style, combining the cold, precise surfaces of a high-security vault with the sophisticated UI of an executive communication tool.

The brand personality is authoritative and silent. It avoids decorative flourishes in favor of functional aesthetics: high-contrast borders that imply structural integrity, metallic textures that suggest physical shielding, and subtle glassmorphism to provide depth without compromising the sense of a solid, enclosed environment. The UI should feel like a high-end hardware device—weighted, responsive, and indestructible.

## Colors
The palette is dominated by a deep, light-absorbing foundation. **Solid Black** serves as the "vault floor," providing the base for all interfaces. **Deep Indigo** is used for tonal layering, defining structural containers and interactive regions.

**Platinum Silver** is the primary accent, used for high-contrast borders, critical iconography, and technical data. Functional colors are used sparingly and with high saturation: a "Matrix-style" green for secure states and a sharp red for potential breaches. This design system utilizes a "High-Contrast Dark" mode by default to ensure maximum legibility and an executive, late-night mission-control feel.

## Typography
Typography is split between technical rigidity and modern clarity. 

**Space Grotesk** is used for all primary headings. Its geometric, slightly "off-kilter" characters evoke the precision of encryption algorithms. For body copy, **Geist** provides a neutral, highly readable sans-serif that maintains a developer-centric cleanliness. **JetBrains Mono** is reserved for metadata, encryption keys, and technical status readouts, reinforcing the "under-the-hood" security narrative. All labels should be set in uppercase with increased letter spacing to mimic aerospace instrumentation.

## Layout & Spacing
The layout philosophy is built on a "Hard Grid." Every element must align to an 8px baseline to maintain a sense of mathematical order. The system uses a fixed 12-column grid for desktop environments to create a structured "cockpit" layout, where information panels are docked at the edges.

Whitespace is used strategically—not to create "airiness," but to create "isolation." Groupings of content should be tightly packed within high-contrast borders, with larger gaps between these "vaulted" modules to emphasize their independence and security.

## Elevation & Depth
Depth in this design system is conveyed through transparency and "Physical Thickness" rather than soft shadows.

1.  **Structural Borders:** Instead of shadows, use 1px or 2px solid Platinum Silver borders to define the edges of objects.
2.  **Backdrop Blurs:** Use heavy backdrop blurs (20px+) on Deep Indigo surfaces to create a glassmorphic effect that feels like thick, bulletproof shielding.
3.  **Inner Glows:** Interactive elements should have a subtle inner glow (Platinum Silver at 10% opacity) to simulate the way light catches the edge of polished metal.
4.  **Scanning Lines:** A global overlay of horizontal scanlines at 2% opacity provides a "live monitor" texture to all elevated surfaces.

## Shapes
The shape language is strictly **Sharp (0px)**. To convey the idea of a solid vault and technical precision, rounded corners are eliminated entirely. This creates a brutalist, industrial silhouette.

Internal components may use a 45-degree chamfered corner for buttons or status badges to reinforce the "military-grade" aesthetic. High-contrast borders are mandatory for all primary containers, using the Platinum Silver token against the Solid Black background.

## Components
### The Tamper-Proof Badge
A signature component of the design system. This badge uses a metallic gradient (Platinum to Steel) with a high-contrast black label. It should feature a "Micro-text" border (0.5rem) that repeats the word "AUTHENTICATED" to simulate physical security foil.

### Scanning Animation
Interactive states and data visualizations should feature a "Scanning Line." This is a 2px tall, glowing Platinum Silver horizontal rule that travels vertically across the container. It should trigger when data is being decrypted or when a secure connection is being established.

### Inputs & Fields
Input fields are styled as "Terminal Blocks." They feature a solid Black background, a 1px Deep Indigo border that turns Platinum Silver on focus, and a blinking square cursor.

### Buttons
Buttons are rectangular, sharp-edged blocks. The primary action button is Solid Platinum Silver with Black text. Secondary buttons are ghost-style with a 1px Silver border and no fill. The hover state should include a subtle "flicker" animation to mimic a digital screen turning on.

### Technical Data Viz
Charts and graphs should use "Wireframe" styling. No solid fills; only 1px strokes in Platinum or Secure Green, with data points marked by small "+" crosshairs.