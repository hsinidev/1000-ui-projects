---
name: Echo-Avenue
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#d1c1d9'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#9a8ca2'
  outline-variant: '#4e4356'
  surface-tint: '#dfb7ff'
  primary: '#dfb7ff'
  on-primary: '#4b007e'
  primary-container: '#9d00ff'
  on-primary-container: '#f7e5ff'
  inverse-primary: '#8c00e5'
  secondary: '#c8c6c5'
  on-secondary: '#303030'
  secondary-container: '#474746'
  on-secondary-container: '#b6b5b4'
  tertiary: '#ffb3af'
  on-tertiary: '#68000e'
  tertiary-container: '#d60029'
  on-tertiary-container: '#ffe6e4'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#f1daff'
  primary-fixed-dim: '#dfb7ff'
  on-primary-fixed: '#2d004f'
  on-primary-fixed-variant: '#6b00b0'
  secondary-fixed: '#e4e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1b1c1c'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#ffdad8'
  tertiary-fixed-dim: '#ffb3af'
  on-tertiary-fixed: '#410006'
  on-tertiary-fixed-variant: '#930019'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Sora
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Sora
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.01em
  body-rt:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  data-lg:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.04em
  data-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.05em
  label-caps:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.1em
spacing:
  unit: 4px
  gutter: 12px
  margin-mobile: 16px
  margin-desktop: 32px
  stack-xs: 4px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

This design system is engineered for the high-stakes environment of live performance and venue management. The brand personality is authoritative, precise, and high-energy, mirroring the intensity of a live concert production. It targets technical directors, sound engineers, and lighting designers who require split-second decision-making capabilities.

The visual style is a hybrid of **High-Tech Minimalism** and **Cybernetic Brutalism**. It prioritizes extreme legibility in low-light environments through a deep dark-mode architecture. The aesthetic leverages vector-line graphics to represent signal flows and data structures, utilizing glowing accents to draw immediate ocular attention to critical state changes. Every element is designed with a "pro-tool" mindset: high information density, zero unnecessary ornamentation, and a tactile, digital-first interface that feels like a physical piece of rack-mounted hardware.

## Colors

The palette of this design system is optimized for high-contrast monitoring and reduced eye strain in dark venues.

*   **Carbon Black (#0A0A0A):** The foundational canvas. It ensures true blacks on OLED displays, minimizing light spill from mobile devices in a performance environment.
*   **Graphite (#2A2A2A):** Used for elevated surfaces, containers, and card backgrounds to create subtle structural depth.
*   **Neon Violet (#9D00FF):** The primary action and brand accent color. It represents energy and the signal "pulse." It is used for active states, primary buttons, and successful connections.
*   **Emergency Red (#FF0033):** Reserved exclusively for clipping alerts, hardware failures, and critical system warnings. It must contrast sharply against both the Black and Violet to trigger immediate user intervention.

## Typography

Typography in this design system is divided by functional intent:

1.  **Headlines (Sora):** Used for brand presence and section headers. Its geometric structure provides a bold, modern high-tech feel.
2.  **Body (Inter):** Utilized for general interface text and descriptions. It offers maximum legibility and a neutral, professional tone.
3.  **Technical Data (JetBrains Mono):** The backbone of the monitoring experience. This monospaced font is used for all numerical values, timestamps, and signal metrics, ensuring that numbers remain vertically aligned and easy to scan during rapid fluctuations.

All data-heavy labels use uppercase with increased tracking to ensure clarity at small sizes on mobile devices.

## Layout & Spacing

This design system employs a **Tight Fluid Grid** based on a 4px baseline unit, tailored for mobile-first technical monitoring. 

The layout philosophy emphasizes "Information Density." Gutters are kept tight (12px) to allow for more data columns on small screens. Layouts utilize a 12-column grid on desktop and a 4-column grid on mobile. Components should snap to the grid to maintain the "rack-mounted" technical look. Significant negative space is discouraged; instead, use logical grouping and line-based separators to create hierarchy.

## Elevation & Depth

Hierarchy is established through **Tonal Layering** and **Luminescent Accents** rather than traditional shadows.

*   **Base:** Carbon Black (#0A0A0A).
*   **Surface Level 1:** Graphite (#2A2A2A) with a 1px stroke of #333333.
*   **Surface Level 2:** Graphite (#333333) for hover states or active card selections.
*   **Glow Effects:** Instead of drop shadows, active elements (like a "Live" toggle or a primary button) utilize a soft outer glow (drop-shadow) using the Neon Violet color with a 15-25% opacity and a 12px blur to simulate a light-emitting diode (LED).
*   **Vector Lines:** 1px width lines in #333333 or Neon Violet are used to connect data points or define borders, reinforcing the technical schematic aesthetic.

## Shapes

The shape language of this design system is **Sharp**. 

All interactive components, containers, and buttons utilize 0px border-radii. This reinforces the "High-End Venue Tech" aesthetic, mimicking the industrial design of professional audio/visual rack equipment. Sharp corners communicate precision, modularity, and technical rigor. Secondary elements like internal progress bars or small status pips may use minimal rounding (2px) if required for visual differentiation, but the primary architectural container is always rectangular.

## Components

*   **Buttons:** Rectangular with no radius. Primary buttons use a Neon Violet background with white or black text. Ghost buttons use a 1px Neon Violet border.
*   **Technical Metrics:** Large, high-contrast JetBrains Mono digits. If a value exceeds a threshold, the digits or their container border should flash Emergency Red.
*   **Status Pips:** Small 1px outlined squares that fill with Neon Violet (Active), remain outlined (Inactive), or pulse Emergency Red (Error).
*   **Input Fields:** Dark Graphite background with a bottom-border only (1px). Focus state shifts the border to Neon Violet with a subtle glow.
*   **Cards/Modules:** Use a "Schematic" style—thin 1px Graphite borders, with a header section separated by a horizontal line.
*   **Vector Toggles:** Switch-style toggles that move horizontally, using Neon Violet for the 'On' state to mimic a physical hardware switch.
*   **Signal Meters:** Vertical or horizontal bar graphs using a segmented block style rather than a continuous fill, providing a more "digital" and precise visual feedback.