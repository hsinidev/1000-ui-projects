---
name: Veritas-Monitor Professional
colors:
  surface: '#141313'
  surface-dim: '#141313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2b2a2a'
  surface-container-highest: '#353434'
  on-surface: '#e5e2e1'
  on-surface-variant: '#c4c7c7'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#8e9192'
  outline-variant: '#444748'
  surface-tint: '#c8c6c5'
  primary: '#c8c6c5'
  on-primary: '#313030'
  primary-container: '#121212'
  on-primary-container: '#7e7d7d'
  inverse-primary: '#5f5e5e'
  secondary: '#c6c6c7'
  on-secondary: '#2f3131'
  secondary-container: '#454747'
  on-secondary-container: '#b4b5b5'
  tertiary: '#c6c6c6'
  on-tertiary: '#2f3131'
  tertiary-container: '#111213'
  on-tertiary-container: '#7d7d7d'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#e3e2e2'
  tertiary-fixed-dim: '#c6c6c6'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#464747'
  background: '#141313'
  on-background: '#e5e2e1'
  surface-variant: '#353434'
typography:
  display-xl:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.02em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.1em
spacing:
  unit: 4px
  gutter: 16px
  margin: 24px
  container-max: 1440px
  col-gap: 1px
---

## Brand & Style
This design system is engineered for the professional audio environment, where accuracy is the only metric of success. The brand personality is clinical, objective, and devoid of emotional ornamentation. It targets audio engineers and acoustic specialists who require a high-fidelity interface that mirrors the precision of the hardware it controls.

The UI style follows a "Laboratory-Grade" aesthetic, utilizing a strict grid and high-contrast elements to ensure legibility in low-light studio environments. Every element exists for a functional purpose; there are no decorative shadows or rounded corners. The visual language draws inspiration from precision measuring instruments and oscilloscope interfaces, prioritizing data density and technical clarity over traditional consumer aesthetics.

## Colors
The color palette is restricted to a monochromatic core with a singular technical accent. The primary background is Matte Black (#121212), chosen to minimize screen glare and eye fatigue during long sessions. Pure White (#FFFFFF) is reserved for critical labels and active states to provide maximum contrast.

Silver (#C0C0C0) serves as the structural color, defining borders, inactive tracks, and secondary metadata. The Technical Accent Blue (#007AFF) is utilized exclusively for data visualization—such as frequency response curves, active signals, and peak indicators—ensuring that information-dense displays remain navigable. Use the accent color sparingly to maintain its signal value.

## Typography
Typography is divided into two distinct functional categories: Communication and Calculation. **Inter** is used for the interface hierarchy, providing a neutral, sans-serif base that remains legible at various scales.

**JetBrains Mono** is used for all technical data, numerical readouts, and small-scale labels. The monospaced nature of the font ensures that numerical values (such as Hz, dB, or timestamps) remain vertically aligned and do not "jump" as values fluctuate. Use `label-caps` for all physical-style markings on the UI, mimicking the silk-screening found on professional rack-mount equipment.

## Layout & Spacing
The layout follows a strict 12-column fixed grid. The spacing rhythm is based on a 4px module, ensuring all elements align to a rigid mathematical structure. Gutters are kept tight to maximize the density of technical information.

Layouts should be structured like an equipment rack. Modules should be stacked or placed side-by-side with 1px Silver dividers to create clear physical separation without wasting space. High-density views (such as parametric EQs or multi-channel monitors) should utilize the full width of the grid, prioritizing horizontal signal flow.

## Elevation & Depth
In this design system, depth is conveyed through "Tonal Layering" and "Low-Contrast Outlines" rather than shadows. All components are essentially flat, sitting on the same physical plane as the interface "faceplate."

Hierarchy is established by varying the darkness of the black background. The base layer is #121212. Interactive or elevated containers use a slightly lighter grey (#1A1A1A) with a 1px Silver (#C0C0C0) or dark grey border. Inset effects are used for input fields or recessed meters to simulate carved or machined slots in a physical metal panel. Avoid all ambient shadows or blurs; clarity is achieved through sharp lines and distinct value shifts.

## Shapes
The shape language is strictly orthogonal. All containers, buttons, and input fields feature 0px border-radii. Sharp corners reinforce the engineering-grade nature of the system, suggesting precision and industrial durability. 

The only exceptions to the rectilinear rule are purely functional data representations, such as circular rotary knobs or specific icons for signal flow. Even in these cases, the "hit area" and surrounding containers remain square.

## Components
### Buttons & Controls
Buttons are rectangular with a 1px Silver border. The "Active" state is indicated by filling the button with Silver and using Black text, or by lighting the 1px bottom border in Accent Blue. No hover transitions are used; state changes must be instantaneous to reflect real-time hardware response.

### Input Fields
Inputs are recessed (darker background than the surface) with monospaced text. The label sits above the field in `label-caps`. When focused, the border color changes to Accent Blue.

### VU Meters & Data Viz
Level meters use a segmented approach rather than a smooth gradient. Each segment represents a specific dB increment. The "Peak" indicator is a single 1px line in Accent Blue that lingers for 500ms after a signal spike.

### Cards & Modules
Modules (like "Limiter" or "Crossover") are bounded by 1px Silver borders. Each module must have a header bar containing the module title in `label-caps` and a toggle switch for bypass functionality.

### Rotary Knobs
For parameters like gain or frequency, use a circular dial with a single 1px "pointer" line. The value readout must be visible at all times in monospaced type below or inside the dial.